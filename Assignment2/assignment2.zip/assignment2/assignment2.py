"""
Koc University, Turkey
KOLT Python Certificate Program
Spring 2019 - Assignment 2
Created by @ipekkoprululu
"""
# Author: <Your_Name_Here>

# Implement your functions here


###############################

# Task 1:
# Create a dictionary
# Read 'list.txt'
# Put the information into the dictionary


###############################

# Task 2:
# Sort the dictionaries of students and professors by their ages
# You can implement your functions into the specified place


###############################

# Task 3:
# Create two files named 'students.txt' and 'professors.txt'
# Write the information in the dictionary into the files


###############################
